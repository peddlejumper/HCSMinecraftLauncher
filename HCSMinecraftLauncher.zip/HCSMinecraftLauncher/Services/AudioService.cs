using System;
using System.IO;
using NAudio.Wave;
using Avalonia.Threading;

namespace HCSMinecraftLauncher.Services
{
    public class AudioService : IDisposable
    {
        private IWavePlayer _player;
        private AudioFileReader _audioFileReader;
        private string _currentFile;
        private bool _isPlaying;

        public bool IsPlaying => _isPlaying;

        public void Play(string filePath)
        {
            try
            {
                Stop();
                
                if (!File.Exists(filePath))
                    throw new FileNotFoundException($"音频文件不存在: {filePath}");
                
                _audioFileReader = new AudioFileReader(filePath);
                _player = new WaveOutEvent();
                _player.Init(_audioFileReader);
                _player.PlaybackStopped += (s, e) => 
                {
                    Dispatcher.UIThread.Post(() => 
                    {
                        _isPlaying = false;
                        _player?.Dispose();
                        _player = null;
                        _audioFileReader?.Dispose();
                        _audioFileReader = null;
                    });
                };
                
                _player.Play();
                _isPlaying = true;
                _currentFile = filePath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"音频播放错误: {ex.Message}");
                Stop();
            }
        }

        public void Stop()
        {
            if (_player != null)
            {
                _player.Stop();
                _player.Dispose();
                _player = null;
            }
            
            if (_audioFileReader != null)
            {
                _audioFileReader.Dispose();
                _audioFileReader = null;
            }
            
            _isPlaying = false;
        }

        public void Dispose()
        {
            Stop();
        }
    }
}