using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace HCSMinecraftLauncher.Services
{
    public static class JavaService
    {
        public static string FindJavaPath()
        {
            var platform = PlatformService.GetPlatformInfo();
            
            if (platform.Name == "Windows")
            {
                var candidates = new List<string>
                {
                    Environment.GetEnvironmentVariable("JAVA_HOME"),
                    @"C:\Program Files\Java",
                    @"C:\Program Files (x86)\Java",
                    Environment.GetEnvironmentVariable("ProgramW6432"),
                    Environment.GetEnvironmentVariable("ProgramFiles(x86)")
                }.Where(p => !string.IsNullOrEmpty(p) && Directory.Exists(p));

                foreach (var baseDir in candidates)
                {
                    var javaDirs = Directory.GetDirectories(baseDir, "jre*", SearchOption.TopDirectoryOnly)
                        .Concat(Directory.GetDirectories(baseDir, "jdk*", SearchOption.TopDirectoryOnly));
                    
                    foreach (var dir in javaDirs)
                    {
                        var javaPath = Path.Combine(dir, "bin", "java.exe");
                        if (File.Exists(javaPath)) return javaPath;
                    }
                }
            }
            else if (platform.Name == "macOS")
            {
                var candidates = new[]
                {
                    "/usr/bin/java",
                    "/Library/Internet Plug-Ins/JavaAppletPlugin.plugin/Contents/Home/bin/java",
                    "/usr/libexec/java_home"
                };

                foreach (var path in candidates)
                {
                    if (File.Exists(path)) return path;
                }

                // Try /usr/libexec/java_home output
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = "/usr/libexec/java_home",
                        Arguments = "-v 17+",
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    };
                    using var process = Process.Start(psi);
                    process.WaitForExit();
                    var home = process.StandardOutput.ReadToEnd().Trim();
                    if (!string.IsNullOrEmpty(home))
                        return Path.Combine(home, "bin", "java");
                }
                catch { }
            }
            else // Linux
            {
                var candidates = new[]
                {
                    "/usr/bin/java",
                    "/usr/lib/jvm/default-java/bin/java",
                    "/usr/lib/jvm/java-17-openjdk/bin/java",
                    "/usr/lib/jvm/java-11-openjdk/bin/java"
                };

                foreach (var path in candidates)
                {
                    if (File.Exists(path)) return path;
                }
            }

            return "java"; // Fallback to PATH
        }
    }
}