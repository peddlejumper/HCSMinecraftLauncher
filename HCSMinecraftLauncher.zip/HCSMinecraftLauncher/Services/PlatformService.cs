using System;
using System.IO;
using System.Runtime.InteropServices;

namespace HCSMinecraftLauncher.Services
{
    public static class PlatformService
    {
        public static PlatformInfo GetPlatformInfo()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                return new PlatformInfo 
                { 
                    Name = "Windows", 
                    MinecraftDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".pycraft"),
                    DefaultMinecraftDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".minecraft")
                };
            
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                return new PlatformInfo 
                { 
                    Name = "macOS", 
                    MinecraftDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "Application Support", "pycraft"),
                    DefaultMinecraftDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "Application Support", "minecraft")
                };
            
            // Linux
            var xdgDataHome = Environment.GetEnvironmentVariable("XDG_DATA_HOME");
            var dataDir = !string.IsNullOrEmpty(xdgDataHome) 
                ? Path.Combine(xdgDataHome, "pycraft") 
                : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".local", "share", "pycraft");
            
            var defaultDir = !string.IsNullOrEmpty(xdgDataHome) 
                ? Path.Combine(xdgDataHome, "minecraft") 
                : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".minecraft");
            
            return new PlatformInfo 
            { 
                Name = "Linux", 
                MinecraftDir = dataDir,
                DefaultMinecraftDir = defaultDir
            };
        }

        public static string GetJavaExecutableName() => 
            RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? "java.exe" : "java";
    }

    public class PlatformInfo
    {
        public string Name { get; set; }
        public string MinecraftDir { get; set; }
        public string DefaultMinecraftDir { get; set; }
    }
}