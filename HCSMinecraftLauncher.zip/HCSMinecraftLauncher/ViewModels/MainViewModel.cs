using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Threading;
using HCSMinecraftLauncher.Models;
using HCSMinecraftLauncher.Services;
using ReactiveUI;

namespace HCSMinecraftLauncher.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly VersionService _versionService;
        private readonly AccountService _accountService;
        private readonly AudioService _audioService;
        private readonly HcsCloudService _hcsCloudService;
        private readonly TaskService _taskService;
        private readonly PlatformInfo _platform;
        
        // UI绑定属性
        private VersionInfo _selectedVersion;
        private Account _selectedAccount;
        private int _downloadProgress;
        private string _downloadStatus = "准备就绪";
        private int _launchProgress;
        private string _launchStatus = "就绪";
        private string _javaPath;
        private int _maxMemory = 2048;
        private int _windowWidth = 854;
        private int _windowHeight = 480;
        private bool _fullscreen;
        private string _jvmArgs = "-XX:+UseG1GC";
        private bool _enableHwAccel;
        private string _versionInfoText = "请选择游戏版本";
        private string _taskNotifyText = "欢迎使用 HCS Minecraft Launcher！";
        private bool _taskRunning;
        private string _bgMusicPath;
        private string _versionCategory = "正式版";
        private ObservableCollection<string> _releaseVersions = new();
        private ObservableCollection<string> _snapshotVersions = new();
        private ObservableCollection<string> _oldVersions = new();
        private ObservableCollection<string> _gameListItems = new();

        public MainViewModel()
        {
            _platform = PlatformService.GetPlatformInfo();
            _versionService = new VersionService();
            _accountService = new AccountService(_platform.MinecraftDir);
            _audioService = new AudioService();
            _hcsCloudService = new HcsCloudService();
            _taskService = new TaskService();
            
            // 初始化目录
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "versions"));
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "libraries"));
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "assets", "indexes"));
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "assets", "objects"));
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "natives"));
            Directory.CreateDirectory(Path.Combine(_platform.MinecraftDir, "mods"));
            
            // 加载账户
            Accounts = new ObservableCollection<Account>(_accountService.GetAccounts());
            SelectedAccount = Accounts.FirstOrDefault(a => a.IsSelected) ?? 
                            (Accounts.Any() ? Accounts.First() : new Account { Username = "Player", Uuid = Guid.NewGuid().ToString(), IsSelected = true });
            
            // Java路径
            JavaPath = JavaService.FindJavaPath();
            
            // 命令初始化
            LoadVersionsCommand = ReactiveCommand.CreateFromTask(LoadVersionsAsync);
            LaunchGameCommand = ReactiveCommand.CreateFromTask(LaunchGameAsync, this.WhenAnyValue(x => x.CanLaunchGame));
            DownloadVersionCommand = ReactiveCommand.CreateFromTask(DownloadVersionAsync, this.WhenAnyValue(x => x.CanDownloadVersion));
            ScanExistingVersionsCommand = ReactiveCommand.CreateFromTask(ScanExistingVersionsAsync);
            ShowSettingsCommand = ReactiveCommand.Create(ShowSettings);
            ShowAccountsCommand = ReactiveCommand.Create(ShowAccounts);
            ShowAboutCommand = ReactiveCommand.Create(ShowAbout);
            ShowAppearanceCommand = ReactiveCommand.Create(ShowAppearance);
            ShowTaskCenterCommand = ReactiveCommand.Create(ShowTaskCenter);
            ShowInstalledGamesCommand = ReactiveCommand.Create(ShowInstalledGames);
            ShowModsCommand = ReactiveCommand.Create(ShowMods);
            ShowHcsLoginCommand = ReactiveCommand.Create(ShowHcsLogin);
            ShowHcsCloudCommand = ReactiveCommand.Create(ShowHcsCloud);
            ShowGuanyuCommand = ReactiveCommand.Create(ShowGuanyu);
            SelectJavaCommand = ReactiveCommand.Create(SelectJava);
            PlayBgMusicCommand = ReactiveCommand.Create(PlayBgMusic);
            StopBgMusicCommand = ReactiveCommand.Create(StopBgMusic);
            UpdateGameListCommand = ReactiveCommand.Create(UpdateGameList);
            
            // 启动时加载版本
            _ = LoadVersionsAsync();
            
            // 监听任务服务
            _taskService.TaskNotify += (msg) => TaskNotifyText = msg;
            _taskService.TaskStarted += () => TaskRunning = true;
            _taskService.TaskCompleted += () => TaskRunning = false;
        }

        // 属性 (简化展示，实际包含完整INPC实现)
        public ObservableCollection<VersionInfo> Versions { get; } = new();
        public ObservableCollection<Account> Accounts { get; }
        public ObservableCollection<string> GameListItems => _gameListItems;
        public string VersionCategory 
        { 
            get => _versionCategory; 
            set => this.RaiseAndSetIfChanged(ref _versionCategory, value, UpdateGameList); 
        }
        public VersionInfo SelectedVersion
        {
            get => _selectedVersion;
            set => this.RaiseAndSetIfChanged(ref _selectedVersion, value, () => 
            {
                UpdateVersionInfo();
                this.RaisePropertyChanged(nameof(CanLaunchGame));
                this.RaisePropertyChanged(nameof(CanDownloadVersion));
            });
        }
        public Account SelectedAccount
        {
            get => _selectedAccount;
            set => this.RaiseAndSetIfChanged(ref _selectedAccount, value, () => 
            {
                if (value != null)
                {
                    _accountService.SetSelectedAccount(value.Username);
                    Username = value.Username;
                }
            });
        }
        public string Username { get; set; } = "Player";
        public int DownloadProgress { get => _downloadProgress; set => this.RaiseAndSetIfChanged(ref _downloadProgress, value); }
        public string DownloadStatus { get => _downloadStatus; set => this.RaiseAndSetIfChanged(ref _downloadStatus, value); }
        public int LaunchProgress { get => _launchProgress; set => this.RaiseAndSetIfChanged(ref _launchProgress, value); }
        public string LaunchStatus { get => _launchStatus; set => this.RaiseAndSetIfChanged(ref _launchStatus, value); }
        public string JavaPath { get => _javaPath; set => this.RaiseAndSetIfChanged(ref _javaPath, value); }
        public int MaxMemory { get => _maxMemory; set => this.RaiseAndSetIfChanged(ref _maxMemory, value); }
        public int WindowWidth { get => _windowWidth; set => this.RaiseAndSetIfChanged(ref _windowWidth, value); }
        public int WindowHeight { get => _windowHeight; set => this.RaiseAndSetIfChanged(ref _windowHeight, value); }
        public bool Fullscreen { get => _fullscreen; set => this.RaiseAndSetIfChanged(ref _fullscreen, value); }
        public string JvmArgs { get => _jvmArgs; set => this.RaiseAndSetIfChanged(ref _jvmArgs, value); }
        public bool EnableHwAccel { get => _enableHwAccel; set => this.RaiseAndSetIfChanged(ref _enableHwAccel, value); }
        public string VersionInfoText { get => _versionInfoText; private set => this.RaiseAndSetIfChanged(ref _versionInfoText, value); }
        public string TaskNotifyText { get => _taskNotifyText; set => this.RaiseAndSetIfChanged(ref _taskNotifyText, value); }
        public bool TaskRunning { get => _taskRunning; set => this.RaiseAndSetIfChanged(ref _taskRunning, value); }
        public bool CanLaunchGame => SelectedVersion != null && SelectedVersion.IsInstalled;
        public bool CanDownloadVersion => SelectedVersion != null && !SelectedVersion.IsInstalled;

        // 命令
        public ReactiveCommand<Unit, Unit> LoadVersionsCommand { get; }
        public ReactiveCommand<Unit, Unit> LaunchGameCommand { get; }
        public ReactiveCommand<Unit, Unit> DownloadVersionCommand { get; }
        public ReactiveCommand<Unit, Unit> ScanExistingVersionsCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowSettingsCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowAccountsCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowAboutCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowAppearanceCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowTaskCenterCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowInstalledGamesCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowModsCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowHcsLoginCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowHcsCloudCommand { get; }
        public ReactiveCommand<Unit, Unit> ShowGuanyuCommand { get; }
        public ReactiveCommand<Unit, Unit> SelectJavaCommand { get; }
        public ReactiveCommand<Unit, Unit> PlayBgMusicCommand { get; }
        public ReactiveCommand<Unit, Unit> StopBgMusicCommand { get; }
        public ReactiveCommand<Unit, Unit> UpdateGameListCommand { get; }

        // 方法实现 (关键部分)
        private async Task LoadVersionsAsync()
        {
            DownloadStatus = "正在获取版本列表...";
            _taskService.StartTask("加载版本列表");
            
            try
            {
                var versions = await _versionService.LoadVersionsAsync();
                
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    Versions.Clear();
                    foreach (var version in versions.OrderByDescending(v => v.ReleaseTime))
                    {
                        Versions.Add(version);
                    }
                    
                    // 分类版本
                    _releaseVersions = new ObservableCollection<string>(
                        versions.Where(v => v.Type == "release").Select(v => v.Id).OrderByDescending(v => v)
                    );
                    _snapshotVersions = new ObservableCollection<string>(
                        versions.Where(v => v.Type == "snapshot").Select(v => v.Id).OrderByDescending(v => v)
                    );
                    _oldVersions = new ObservableCollection<string>(
                        versions.Where(v => v.Type == "old_alpha" || v.Type == "old_beta").Select(v => v.Id).OrderByDescending(v => v)
                    );
                    
                    if (Versions.Count > 0 && SelectedVersion == null)
                    {
                        SelectedVersion = Versions.FirstOrDefault();
                    }
                    
                    UpdateGameList();
                });
                
                DownloadStatus = $"已加载 {versions.Count} 个版本（正式{ _releaseVersions.Count}，快照{ _snapshotVersions.Count}，远古{ _oldVersions.Count}）";
                _taskService.CompleteTask("版本列表加载完成");
            }
            catch (Exception ex)
            {
                DownloadStatus = $"加载失败: {ex.Message}";
                _taskService.FailTask($"版本加载失败: {ex.Message}");
            }
        }

        private void UpdateGameList()
        {
            _gameListItems.Clear();
            
            switch (VersionCategory)
            {
                case "正式版":
                    foreach (var v in _releaseVersions) _gameListItems.Add(v);
                    break;
                case "快照版":
                    foreach (var v in _snapshotVersions) _gameListItems.Add(v);
                    break;
                case "远古版":
                    foreach (var v in _oldVersions) _gameListItems.Add(v);
                    break;
            }
        }

        private async Task LaunchGameAsync()
        {
            if (!CanLaunchGame || SelectedVersion == null) return;
            
            _taskService.StartTask($"启动游戏: {SelectedVersion.Id}");
            LaunchProgress = 10;
            LaunchStatus = "准备启动参数...";
            
            try
            {
                var classpath = _versionService.GetClasspath(SelectedVersion.Id);
                var nativesDir = Path.Combine(_platform.MinecraftDir, "natives");
                var assetsDir = Path.Combine(_platform.MinecraftDir, "assets");
                
                var args = new List<string>
                {
                    $"-Xmx{MaxMemory}M",
                    "-Xms512M",
                    $"-Djava.library.path=\"{nativesDir}\"",
                    "-Dminecraft.launcher.brand=hcs-launcher",
                    "-Dminecraft.launcher.version=1.0"
                };
                
                if (!string.IsNullOrWhiteSpace(JvmArgs))
                {
                    args.AddRange(JvmArgs.Split(' ', StringSplitOptions.RemoveEmptyEntries));
                }
                
                if (EnableHwAccel)
                {
                    args.Add("-Dsun.java2d.opengl=true");
                }
                
                // 确定主类
                string mainClass = "net.minecraft.client.main.Main";
                if (SelectedVersion.Id.Contains("forge", StringComparison.OrdinalIgnoreCase))
                {
                    mainClass = "net.minecraft.launchwrapper.Launch";
                    args.Add("--tweakClass");
                    args.Add("net.minecraftforge.fml.common.launcher.FMLTweaker");
                }
                else if (SelectedVersion.Id.Contains("fabric", StringComparison.OrdinalIgnoreCase))
                {
                    mainClass = "net.fabricmc.loader.launch.knot.KnotClient";
                }
                
                args.Add("-cp");
                args.Add($"\"{classpath}\"");
                args.Add(mainClass);
                args.Add("--username");
                args.Add($"\"{Username}\"");
                args.Add("--version");
                args.Add($"\"{SelectedVersion.Id}\"");
                args.Add("--gameDir");
                args.Add($"\"{_platform.MinecraftDir}\"");
                args.Add("--assetsDir");
                args.Add($"\"{assetsDir}\"");
                args.Add("--assetIndex");
                args.Add("1.16");
                args.Add("--uuid");
                args.Add("\"00000000-0000-0000-0000-000000000000\"");
                args.Add("--accessToken");
                args.Add("\"0\"");
                args.Add("--userType");
                args.Add("mojang");
                args.Add("--width");
                args.Add(WindowWidth.ToString());
                args.Add("--height");
                args.Add(WindowHeight.ToString());
                
                if (Fullscreen)
                {
                    args.Add("--fullscreen");
                }
                
                LaunchProgress = 50;
                LaunchStatus = "启动游戏进程...";
                
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = JavaPath,
                    Arguments = string.Join(" ", args),
                    WorkingDirectory = _platform.MinecraftDir,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                
                // macOS 特殊处理
                if (_platform.Name == "macOS")
                {
                    psi.EnvironmentVariables["DYLD_LIBRARY_PATH"] = nativesDir;
                }
                
                System.Diagnostics.Process.Start(psi);
                
                LaunchProgress = 100;
                LaunchStatus = $"✓ 已启动 Minecraft {SelectedVersion.Id}";
                _taskService.CompleteTask($"游戏启动成功: {SelectedVersion.Id}");
            }
            catch (Exception ex)
            {
                LaunchStatus = $"✗ 启动失败: {ex.Message}";
                LaunchProgress = 0;
                _taskService.FailTask($"游戏启动失败: {ex.Message}");
            }
        }

        private async Task DownloadVersionAsync()
        {
            if (!CanDownloadVersion || SelectedVersion == null) return;
            
            _taskService.StartTask($"下载版本: {SelectedVersion.Id}");
            DownloadStatus = "开始下载...";
            DownloadProgress = 0;
            
            try
            {
                var progress = new Progress<(int progress, string status)>(p =>
                {
                    DownloadProgress = p.progress;
                    DownloadStatus = p.status;
                });
                
                await _versionService.DownloadVersionAsync(SelectedVersion.Id, progress);
                
                // 标记为已安装
                SelectedVersion.IsInstalled = true;
                this.RaisePropertyChanged(nameof(CanLaunchGame));
                this.RaisePropertyChanged(nameof(CanDownloadVersion));
                UpdateVersionInfo();
                
                _taskService.CompleteTask($"版本下载完成: {SelectedVersion.Id}");
            }
            catch (Exception ex)
            {
                DownloadStatus = $"✗ 下载失败: {ex.Message}";
                DownloadProgress = 0;
                _taskService.FailTask($"版本下载失败: {ex.Message}");
            }
        }

        private async Task ScanExistingVersionsAsync()
        {
            _taskService.StartTask("扫描已有游戏");
            DownloadStatus = "扫描中...";
            
            try
            {
                var imported = await _versionService.ScanExistingVersionsAsync();
                DownloadStatus = $"成功导入 {imported} 个版本";
                await LoadVersionsAsync();
                _taskService.CompleteTask($"扫描完成，导入 {imported} 个版本");
            }
            catch (Exception ex)
            {
                DownloadStatus = $"扫描失败: {ex.Message}";
                _taskService.FailTask($"扫描失败: {ex.Message}");
            }
        }

        private void UpdateVersionInfo()
        {
            if (SelectedVersion == null)
            {
                VersionInfoText = "请选择游戏版本";
                return;
            }
            
            VersionInfoText = $"版本ID: {SelectedVersion.Id}\n" +
                              $"类型: {SelectedVersion.Type}\n" +
                              $"发布时间: {SelectedVersion.ReleaseTime:yyyy-MM-dd HH:mm:ss}\n" +
                              $"状态: {(SelectedVersion.IsInstalled ? "✓ 已安装" : "✗ 未安装")}\n" +
                              $"平台: {_platform.Name}";
        }

        // 其他UI命令方法 (简化)
        private void ShowSettings() => OpenDialog<SettingsViewModel>();
        private void ShowAccounts() => OpenDialog<AccountsViewModel>();
        private void ShowAbout() => OpenDialog<AboutViewModel>();
        private void ShowAppearance() => OpenDialog<AppearanceViewModel>();
        private void ShowTaskCenter() => OpenDialog<TaskCenterViewModel>();
        private void ShowInstalledGames() => OpenDialog<InstalledGamesViewModel>();
        private void ShowMods() => OpenDialog<ModsViewModel>();
        private void ShowHcsLogin() => OpenDialog<HcsLoginViewModel>();
        private void ShowHcsCloud() => OpenDialog<HcsCloudViewModel>();
        private void ShowGuanyu() => OpenDialog<GuanyuViewModel>();
        private void SelectJava() { /* 文件选择对话框 */ }
        private void PlayBgMusic() { /* 音频文件选择 */ }
        private void StopBgMusic() => _audioService.Stop();
        
        private void OpenDialog<TViewModel>() where TViewModel : ViewModelBase, new()
        {
            // 实际实现中打开对应Dialog
            Console.WriteLine($"打开对话框: {typeof(TViewModel).Name}");
        }
        
        // 账户管理
        public void AddAccount(string username)
        {
            if (string.IsNullOrWhiteSpace(username) || Accounts.Any(a => a.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
                return;
                
            var account = new Account { Username = username, Uuid = Guid.NewGuid().ToString() };
            _accountService.AddAccount(account);
            Accounts.Add(account);
            SelectedAccount = account;
        }
        
        public void RemoveAccount(string username)
        {
            var account = Accounts.FirstOrDefault(a => a.Username == username);
            if (account != null)
            {
                _accountService.RemoveAccount(username);
                Accounts.Remove(account);
                SelectedAccount = Accounts.FirstOrDefault() ?? new Account { Username = "Player", Uuid = Guid.NewGuid().ToString() };
            }
        }
    }
}